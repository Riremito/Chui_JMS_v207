var status = 0;
var selectedType = -1;
var selectedItem = -1;

function start() {
    status = -2;
    action(1, 0, 0);
}

function action(mode, type, selection) {		
    if (mode == 1) {
	status++;
    } else {
	cm.dispose();
	return;
    }
	cm.sendRepairWindow();
	cm.dispose();
}