/**
	Mr. Oh - Dungeon : Sleepywood (105040300)
**/

function start() {
    cm.sendStorage();
    cm.dispose();
}