
function action(mode, type, selection) {
    cm.sendNext("It looks like there's nothing suspecious in the area.");
    cm.safeDispose();
}