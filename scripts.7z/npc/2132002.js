function action(mode, type, selection) {
    cm.sendNext("The magic of this forest is amazing...");
    cm.dispose();
}