function action(mode, type, selection) {
    cm.sendNext("Being young doesn't mean I'm any different from those guys. I'll show them!");
    cm.dispose();
}