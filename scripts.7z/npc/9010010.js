/* 	Cassandra
*/

function action(mode, type, selection) {
    cm.sendOk ("You want me to tell you what my crystal of fortune found out?");
    cm.safeDispose()
}