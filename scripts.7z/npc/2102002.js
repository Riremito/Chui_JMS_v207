/*
	Syras - Ariant Station Platform(260000100)
*/

var cost = 6000;
var status = -1;

function action(mode, type, selection) {
    cm.sendOk("Hope you enjoy your stay at Ariant.");
    cm.dispose();
}
