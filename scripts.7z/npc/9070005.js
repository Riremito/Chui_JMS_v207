var status = -1;

function action(mode, type, selection) {
	cm.sendNext("Hope you enjoy Battle Mode!");
	cm.dispose();
}