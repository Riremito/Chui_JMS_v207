/* 	Mr. Hwang - Singapore
	Storage
*/
function start() {
    cm.sendStorage();
    cm.dispose();
}