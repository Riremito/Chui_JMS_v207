/* 
 * NPC  : Donations
 * Maps : Every town
 */

function action(mode, type, selection) {
    cm.sendOk("A tiny writing on the wall states the following: Please make donations for the betterment of this town! May the spirits watch your every step for those that made the donations.");
    cm.safeDispose();
}