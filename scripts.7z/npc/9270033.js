/* 	Engine room, bob
*/

function start() {
    cm.warp(541010110);
}

function action(mode, type, selection) {
    cm.dispose();
}