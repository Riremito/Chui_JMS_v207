var status = -1;

function action(mode, type, selection) {
	cm.sendOk("Oh, how I love Valentines' Day!");
	cm.dispose();
}