/**
	Trina - Orbis : Orbis (200000000)
**/

function start() {
    cm.sendStorage();
    cm.dispose();
}