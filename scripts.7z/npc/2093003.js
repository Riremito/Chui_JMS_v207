/*
	Mr. Gong - Herb Town : Herb Town (251000000)
*/

function action(mode, type, selection) {
    cm.sendStorage();
    cm.dispose();
}