function action(mode, type, selection) {
	cm.warp(101040311, 0);
	cm.dispose();
}