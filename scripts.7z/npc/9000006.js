/* Author: aaroncsn(MapleSea Like)
	NPC Name: 		Vikoon
	Map(s): 		Hidden Street: Leaving the Event(109050001)
	Description: 		Some random pirate
*/

function start(){
	cm.sendOk("Hey hey!!! Find the Treasure Scroll! I lost the map somewhere and I can't leave without it.");
	cm.dispose();
}