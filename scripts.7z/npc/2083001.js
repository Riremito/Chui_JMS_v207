/*
	Encrypted Slate of the Squad - Leafre Cave of life
*/

var status = -1;

function action(mode, type, selection) {
    cm.warp(240050400,0);
    cm.dispose();
}