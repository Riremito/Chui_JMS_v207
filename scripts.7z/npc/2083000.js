/*
	Encrypted Slate of the Squad - Leafre Cave of life
*/

var status = -1;

function action(mode, type, selection) {
	cm.sendOk("You can't read the words on the slate. You have no idea where to use it.");
	cm.safeDispose();
}