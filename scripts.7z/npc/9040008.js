/* Guild Rank Board */

function start() {
    cm.displayGuildRanks();
    cm.dispose();
}