/* 
 *   NPC   : Kenta
 *   Map   : Aquariun - Zoo
 */

function start() {
	cm.dispose();
}

function action(mode, type, selection) {
    cm.dispose();
}