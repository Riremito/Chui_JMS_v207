function action(mode, type, selection) {
    cm.sendNext("Call me Dark Lord. I will give thieves a place in society... watch in a few years!");
    cm.dispose();
}