/*
Calico - Nautilus' Port
*/

function start() {
    cm.sendOk("Zzzz..");
}

function action(mode, type, selection) {
    cm.dispose();
}
