var status = 0;
var request;

function start() {
    status = -1;
    action(1, 0, 0);
}


function action(mode, type, selection) {
    cm.warp(980000000,4);
    cm.dispose();
}


